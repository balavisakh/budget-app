//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DKEoUSU3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D2rNSgqT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D2rNSgqT.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Qd367sjc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
