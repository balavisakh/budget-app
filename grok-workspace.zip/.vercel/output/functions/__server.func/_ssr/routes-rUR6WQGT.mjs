import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ChevronRight, i as Pencil, o as ChevronLeft, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as Slot, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-rUR6WQGT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,color,border-color,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/30 disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "border border-border bg-surface text-fg hover:bg-surface-muted",
			ghost: "text-muted hover:bg-surface-muted hover:text-fg",
			danger: "border border-negative/30 bg-surface text-negative hover:bg-negative/10"
		},
		size: {
			md: "h-11 px-4",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, type, ref, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		type: asChild ? type : type ?? "button",
		...props
	});
}
var EXPENSE_CATEGORIES = [
	"Housing",
	"Groceries",
	"Transport",
	"Dining",
	"Utilities",
	"Health",
	"Personal"
];
var INCOME_CATEGORIES = [
	"Salary",
	"Freelance",
	"Other"
];
var MAX_CENTS = 1e8;
var money = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD"
});
function formatMoney(cents) {
	return money.format(cents / 100);
}
function centsToInput(cents) {
	return (cents / 100).toFixed(2);
}
function monthKey(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}
function shiftMonth(month, delta) {
	const [year, monthIndex] = month.split("-").map(Number);
	return monthKey(new Date(year, monthIndex - 1 + delta, 1));
}
function formatMonth(month) {
	const [year, monthIndex] = month.split("-").map(Number);
	return new Intl.DateTimeFormat("en-US", {
		month: "long",
		year: "numeric"
	}).format(new Date(year, monthIndex - 1, 1));
}
function formatDay(iso) {
	const [year, monthIndex, day] = iso.split("-").map(Number);
	return new Intl.DateTimeFormat("en-US", {
		month: "short",
		day: "numeric"
	}).format(new Date(year, monthIndex - 1, day));
}
function defaultDateForMonth(month, today = /* @__PURE__ */ new Date()) {
	if (month === monthKey(today)) return `${month}-${String(today.getDate()).padStart(2, "0")}`;
	return `${month}-01`;
}
function dateInMonth(month, day) {
	const [year, monthIndex] = month.split("-").map(Number);
	const last = new Date(year, monthIndex, 0).getDate();
	return `${month}-${String(Math.min(Math.max(1, day), last)).padStart(2, "0")}`;
}
function buildSample(month) {
	return [
		{
			day: 1,
			kind: "income",
			amountCents: 52e4,
			category: "Salary",
			note: "Payroll"
		},
		{
			day: 12,
			kind: "income",
			amountCents: 84e3,
			category: "Freelance",
			note: "Studio invoice"
		},
		{
			day: 1,
			kind: "expense",
			amountCents: 165e3,
			category: "Housing",
			note: "Rent"
		},
		{
			day: 4,
			kind: "expense",
			amountCents: 8640,
			category: "Groceries",
			note: "Market run"
		},
		{
			day: 5,
			kind: "expense",
			amountCents: 9200,
			category: "Transport",
			note: "Monthly pass"
		},
		{
			day: 8,
			kind: "expense",
			amountCents: 4820,
			category: "Dining",
			note: "Dinner out"
		},
		{
			day: 11,
			kind: "expense",
			amountCents: 12415,
			category: "Utilities",
			note: "Electric and water"
		},
		{
			day: 14,
			kind: "expense",
			amountCents: 6380,
			category: "Groceries",
			note: "Midweek shop"
		},
		{
			day: 18,
			kind: "expense",
			amountCents: 2850,
			category: "Health",
			note: "Pharmacy"
		},
		{
			day: 21,
			kind: "expense",
			amountCents: 3410,
			category: "Dining",
			note: "Lunch"
		},
		{
			day: 23,
			kind: "expense",
			amountCents: 7125,
			category: "Groceries",
			note: "Weekend shop"
		},
		{
			day: 26,
			kind: "expense",
			amountCents: 1599,
			category: "Personal",
			note: "Subscriptions"
		}
	].map((row, index) => ({
		id: `${month}-sample-${index + 1}`,
		kind: row.kind,
		amountCents: row.amountCents,
		category: row.category,
		note: row.note,
		date: dateInMonth(month, row.day)
	}));
}
function isTransaction(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	return typeof row.id === "string" && (row.kind === "income" || row.kind === "expense") && typeof row.amountCents === "number" && Number.isInteger(row.amountCents) && row.amountCents > 0 && typeof row.category === "string" && row.category.trim().length > 0 && typeof row.note === "string" && typeof row.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(row.date);
}
function categoriesFor(kind) {
	return kind === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
}
function emptyDraft(month, today = /* @__PURE__ */ new Date()) {
	return {
		kind: "expense",
		amount: "",
		category: "Groceries",
		date: defaultDateForMonth(month, today),
		note: ""
	};
}
function draftFromTransaction(transaction) {
	return {
		kind: transaction.kind,
		amount: centsToInput(transaction.amountCents),
		category: transaction.category,
		date: transaction.date,
		note: transaction.note
	};
}
function isRealDate(iso) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return false;
	const year = Number(match[1]);
	const monthIndex = Number(match[2]);
	const day = Number(match[3]);
	const date = new Date(year, monthIndex - 1, day);
	return date.getFullYear() === year && date.getMonth() === monthIndex - 1 && date.getDate() === day;
}
function parseDollarsToCents(input) {
	const cleaned = input.trim().replace(/[$,]/g, "");
	if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
	const [whole, fraction = ""] = cleaned.split(".");
	const cents = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
	if (!Number.isInteger(cents) || cents <= 0 || cents > MAX_CENTS) return null;
	return cents;
}
function parseDraft(draft) {
	const amountCents = parseDollarsToCents(draft.amount);
	if (amountCents === null) return {
		ok: false,
		error: "Enter an amount from $0.01 to $1,000,000."
	};
	const category = draft.category.trim().replace(/\s+/g, " ");
	if (!category || category.length > 40) return {
		ok: false,
		error: "Add a category, up to 40 characters."
	};
	if (!isRealDate(draft.date)) return {
		ok: false,
		error: "Choose a valid date."
	};
	const note = draft.note.trim().replace(/\s+/g, " ").slice(0, 80);
	return {
		ok: true,
		value: {
			kind: draft.kind,
			amountCents,
			category,
			date: draft.date,
			note
		}
	};
}
function withPercents(entries, total) {
	if (total <= 0 || entries.length === 0) return [];
	const ranked = entries.map((entry) => {
		const exact = entry.cents / total * 100;
		return {
			...entry,
			pct: Math.floor(exact),
			frac: exact - Math.floor(exact)
		};
	}).sort((a, b) => b.frac - a.frac || b.cents - a.cents);
	let leftover = 100 - ranked.reduce((sum, entry) => sum + entry.pct, 0);
	for (const entry of ranked) {
		if (leftover <= 0) break;
		entry.pct += 1;
		leftover -= 1;
	}
	return ranked.map(({ category, cents, pct }) => ({
		category,
		cents,
		pct
	})).sort((a, b) => b.cents - a.cents || a.category.localeCompare(b.category));
}
function summarize(transactions) {
	let income = 0;
	let expenses = 0;
	const incomeMap = /* @__PURE__ */ new Map();
	const expenseMap = /* @__PURE__ */ new Map();
	for (const transaction of transactions) if (transaction.kind === "income") {
		income += transaction.amountCents;
		incomeMap.set(transaction.category, (incomeMap.get(transaction.category) ?? 0) + transaction.amountCents);
	} else {
		expenses += transaction.amountCents;
		expenseMap.set(transaction.category, (expenseMap.get(transaction.category) ?? 0) + transaction.amountCents);
	}
	return {
		income,
		expenses,
		remaining: income - expenses,
		incomeCategories: withPercents([...incomeMap.entries()].map(([category, cents]) => ({
			category,
			cents
		})), income),
		expenseCategories: withPercents([...expenseMap.entries()].map(([category, cents]) => ({
			category,
			cents
		})), expenses)
	};
}
function inMonth(transactions, month) {
	return transactions.filter((transaction) => transaction.date.startsWith(`${month}-`)).sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
}
function goalStanding(remaining, targetCents) {
	if (targetCents <= 0) return {
		pct: 0,
		toward: 0,
		gap: remaining,
		state: "unset"
	};
	if (remaining < 0) return {
		pct: 0,
		toward: 0,
		gap: remaining - targetCents,
		state: "overspent"
	};
	const toward = Math.min(remaining, targetCents);
	const pct = Math.round(toward / targetCents * 100);
	if (remaining >= targetCents) return {
		pct: 100,
		toward: targetCents,
		gap: remaining - targetCents,
		state: "covered"
	};
	return {
		pct,
		toward,
		gap: remaining - targetCents,
		state: "short"
	};
}
var fieldClass$1 = "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";
function EntryFields({ draft, onChange, error, idPrefix }) {
	const errorId = (0, import_react.useId)();
	const presets = categoriesFor(draft.kind);
	function patch(partial) {
		onChange({
			...draft,
			...partial
		});
	}
	function setKind(kind) {
		if (kind === draft.kind) return;
		const nextCategory = categoriesFor(draft.kind).includes(draft.category) ? kind === "income" ? "Salary" : "Groceries" : draft.category;
		onChange({
			...draft,
			kind,
			category: nextCategory
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1 rounded-lg bg-surface-muted p-1",
				role: "group",
				"aria-label": "Entry type",
				children: ["expense", "income"].map((kind) => {
					const selected = draft.kind === kind;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": selected,
						onClick: () => setKind(kind),
						className: cn("h-11 rounded-md text-sm font-medium capitalize transition-[background-color,color,box-shadow] duration-150", selected ? "bg-surface text-fg shadow-panel" : "text-muted hover:text-fg"),
						children: kind
					}, kind);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-2",
				htmlFor: `${idPrefix}-amount`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Amount"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted",
						"aria-hidden": true,
						children: "$"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${idPrefix}-amount`,
						className: cn(fieldClass$1, "pl-7 font-medium tabular-nums"),
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "0.00",
						value: draft.amount,
						"aria-invalid": error ? true : void 0,
						"aria-describedby": error ? errorId : void 0,
						onChange: (event) => patch({ amount: event.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						id: `${idPrefix}-category-label`,
						children: "Category"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						role: "group",
						"aria-labelledby": `${idPrefix}-category-label`,
						children: presets.map((category) => {
							const selected = draft.category === category;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": selected,
								onClick: () => patch({ category }),
								className: cn("h-11 rounded-full border px-3 text-sm font-medium transition-[background-color,color,border-color] duration-150", selected ? "border-accent bg-accent text-accent-fg" : "border-border bg-surface text-fg hover:bg-surface-muted"),
								children: category
							}, category);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${idPrefix}-category`,
						className: fieldClass$1,
						"aria-labelledby": `${idPrefix}-category-label`,
						autoComplete: "off",
						maxLength: 40,
						placeholder: "Or type your own",
						value: draft.category,
						onChange: (event) => patch({ category: event.target.value })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: `${idPrefix}-date`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${idPrefix}-date`,
						className: cn(fieldClass$1, "tabular-nums"),
						type: "date",
						value: draft.date,
						onChange: (event) => patch({ date: event.target.value })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: `${idPrefix}-note`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Note"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${idPrefix}-note`,
						className: fieldClass$1,
						autoComplete: "off",
						maxLength: 80,
						placeholder: "Optional",
						value: draft.note,
						onChange: (event) => patch({ note: event.target.value })
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: errorId,
				role: "alert",
				className: "text-sm text-negative",
				children: error
			}) : null
		]
	});
}
function EntryForm({ month, onCreate }) {
	const [draft, setDraft] = (0, import_react.useState)(() => emptyDraft(month));
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setDraft((current) => {
			if (current.date.startsWith(month)) return current;
			return {
				...current,
				date: defaultDateForMonth(month)
			};
		});
	}, [month]);
	function submit(event) {
		event.preventDefault();
		const parsed = parseDraft(draft);
		if (!parsed.ok) {
			setError(parsed.error);
			setNotice("");
			return;
		}
		onCreate(parsed.value);
		setDraft({
			...draft,
			amount: "",
			note: ""
		});
		setError("");
		setNotice(`Added ${formatMoney(parsed.value.amountCents)} to ${formatMonth(parsed.value.date.slice(0, 7))}.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "New entry"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: "Income or an expense. The balance updates immediately."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-col gap-4",
				onSubmit: submit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryFields, {
						draft,
						idPrefix: "new",
						error,
						onChange: (next) => {
							setDraft(next);
							if (notice) setNotice("");
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: draft.kind === "income" ? "Add income" : "Add expense"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "min-h-5 text-sm text-positive",
						children: notice
					})
				]
			})
		]
	});
}
function EditDialog({ draft, onChange, onOpenChange, onSave }) {
	const [error, setError] = (0, import_react.useState)("");
	const open = draft !== null;
	function save(event) {
		event.preventDefault();
		if (!draft) return;
		const parsed = parseDraft(draft);
		if (!parsed.ok) {
			setError(parsed.error);
			return;
		}
		onSave(parsed.value);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next) {
				setError("");
				onOpenChange(false);
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay-fade fixed inset-0 z-40 bg-fg/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "dialog-pop fixed top-1/2 right-4 left-4 z-50 mx-auto w-full max-w-md overflow-y-auto rounded-2xl border border-border bg-surface p-5 shadow-panel",
			"aria-describedby": "edit-entry-description",
			onOpenAutoFocus: (event) => {
				event.preventDefault();
				document.getElementById("edit-amount")?.focus();
			},
			children: [draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "pr-12 font-display text-2xl font-medium tracking-tight",
						children: "Edit entry"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						id: "edit-entry-description",
						className: "mt-1 text-sm text-muted",
						children: "Changes apply to this month’s balance right away."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryFields, {
							draft,
							idPrefix: "edit",
							error,
							onChange: (next) => {
								setError("");
								onChange(next);
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								children: "Cancel"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save"
						})]
					})
				]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "absolute top-3 right-3",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})
			})]
		})] })
	});
}
function Tip({ active, payload }) {
	const row = payload?.[0]?.payload;
	if (!active || !row) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-surface px-3 py-2 text-sm shadow-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: row.category
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums text-muted",
			children: [
				formatMoney(row.cents),
				" · ",
				row.pct,
				"%"
			]
		})]
	});
}
function SpendingChart({ monthLabel, categories, activeCategory, onSelectCategory, reduceMotion }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 rounded-2xl border border-border bg-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "Spending"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: monthLabel
			})]
		}), categories.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm text-pretty text-muted",
			children: [
				"No expenses in ",
				monthLabel,
				" yet. Add one to see the breakdown."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid items-center gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56 min-w-0",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: categories,
						layout: "vertical",
						margin: {
							top: 4,
							right: 8,
							left: 0,
							bottom: 4
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								type: "number",
								hide: true,
								domain: [0, "dataMax"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								type: "category",
								dataKey: "category",
								width: 92,
								interval: 0,
								axisLine: false,
								tickLine: false,
								tick: {
									fill: "var(--color-muted)",
									fontSize: 12
								},
								tickFormatter: (value) => value.length > 14 ? `${value.slice(0, 13)}…` : value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								cursor: { fill: "var(--color-surface-muted)" },
								content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "cents",
								barSize: 14,
								radius: [
									0,
									6,
									6,
									0
								],
								isAnimationActive: !reduceMotion,
								children: categories.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
									fill: "var(--color-accent)",
									fillOpacity: !activeCategory || activeCategory === row.category ? 1 : .35
								}, row.category))
							})
						]
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3 text-xs font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amount" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1",
					children: categories.map((row) => {
						const selected = activeCategory === row.category;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-border first:border-t-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": selected,
								onClick: () => onSelectCategory(selected ? null : row.category),
								className: cn("flex h-11 w-full items-center justify-between gap-3 rounded-md px-2 text-left transition-colors duration-150", selected ? "bg-surface-muted" : "hover:bg-surface-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-sm font-medium",
									children: row.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-sm tabular-nums",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: formatMoney(row.cents)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-3 inline-block w-10 text-right text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sr-only",
												children: ", "
											}),
											row.pct,
											"%"
										]
									})]
								})]
							})
						}, row.category);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "Select a category to filter the list below."
				})
			] })]
		})]
	});
}
var filters = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "income",
		label: "Income"
	},
	{
		id: "expense",
		label: "Expenses"
	}
];
function TransactionList({ monthLabel, transactions, kindFilter, categoryFilter, onKindFilter, onClearCategory, onUpdate, onDelete, onLoadSample, monthIsEmpty }) {
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [editDraft, setEditDraft] = (0, import_react.useState)(null);
	function openEdit(transaction) {
		setConfirmId(null);
		setEditing(transaction);
		setEditDraft(draftFromTransaction(transaction));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-medium tracking-tight",
					children: "Entries"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						transactions.length,
						" in view · ",
						monthLabel
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [categoryFilter ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onClearCategory,
						className: "inline-flex h-11 items-center gap-2 rounded-full border border-border bg-surface-muted px-3 text-sm font-medium",
						children: [
							categoryFilter,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Clear category filter"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
								className: "size-4 text-muted",
								"aria-hidden": true
							})
						]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid shrink-0 grid-cols-3 gap-1 rounded-lg bg-surface-muted p-1",
						role: "group",
						"aria-label": "Filter entries",
						children: filters.map((filter) => {
							const selected = kindFilter === filter.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": selected,
								onClick: () => onKindFilter(filter.id),
								className: cn("h-11 rounded-md px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-150", selected ? "bg-surface text-fg shadow-panel" : "text-muted hover:text-fg"),
								children: filter.label
							}, filter.id);
						})
					})]
				})]
			}),
			monthIsEmpty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-md border border-dashed border-border px-4 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-pretty text-muted",
					children: [
						"Nothing recorded in ",
						monthLabel,
						"."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "secondary",
					onClick: onLoadSample,
					children: "Load sample entries"
				})]
			}) : transactions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "No entries match this filter."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4",
				children: transactions.map((transaction) => {
					const confirming = confirmId === transaction.id;
					const signed = transaction.kind === "income" ? transaction.amountCents : -transaction.amountCents;
					const detail = transaction.note ? `${formatDay(transaction.date)} · ${transaction.note}` : `${formatDay(transaction.date)} · ${transaction.kind === "income" ? "Income" : "Expense"}`;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-border first:border-t-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-medium",
										children: transaction.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm text-muted",
										children: detail
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("w-28 shrink-0 text-right text-sm font-semibold whitespace-nowrap tabular-nums sm:text-base", transaction.kind === "income" ? "text-positive" : "text-negative"),
									children: formatMoney(signed)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": `Edit ${transaction.category}`,
										onClick: () => openEdit(transaction),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": `Delete ${transaction.category}`,
										"aria-expanded": confirming,
										onClick: () => setConfirmId(confirming ? null : transaction.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								})
							]
						}), confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									"Delete this ",
									formatMoney(transaction.amountCents),
									" entry?"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => setConfirmId(null),
									children: "Keep"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: () => {
										onDelete(transaction.id);
										setConfirmId(null);
									},
									children: "Delete"
								})]
							})]
						}) : null]
					}, transaction.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted",
				children: "Entries stay on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditDialog, {
				draft: editDraft,
				onChange: setEditDraft,
				onOpenChange: (open) => {
					if (!open) {
						setEditing(null);
						setEditDraft(null);
					}
				},
				onSave: (input) => {
					if (!editing) return;
					onUpdate(editing.id, input);
					setEditing(null);
					setEditDraft(null);
				}
			})
		]
	});
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function initialTransactions() {
	return buildSample(monthKey(/* @__PURE__ */ new Date()));
}
var useBudget = create()(persist((set) => ({
	transactions: initialTransactions(),
	goalName: "Emergency fund",
	goalTargetCents: 48e4,
	addTransaction: (input) => set((state) => ({ transactions: [{
		...input,
		id: crypto.randomUUID()
	}, ...state.transactions] })),
	updateTransaction: (id, input) => set((state) => ({ transactions: state.transactions.map((transaction) => transaction.id === id ? {
		...input,
		id
	} : transaction) })),
	deleteTransaction: (id) => set((state) => ({ transactions: state.transactions.filter((transaction) => transaction.id !== id) })),
	setGoalName: (name) => set({ goalName: name.trim().slice(0, 40) || "Savings" }),
	setGoalTargetCents: (cents) => set({ goalTargetCents: cents }),
	loadSample: (month) => set((state) => {
		if (state.transactions.some((transaction) => transaction.date.startsWith(`${month}-`))) return state;
		return { transactions: [...buildSample(month), ...state.transactions] };
	})
}), {
	name: "ledger-budget-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage),
	merge: (persisted, current) => {
		const stored = persisted ?? {};
		const transactions = Array.isArray(stored.transactions) ? stored.transactions.filter(isTransaction) : current.transactions;
		const goalName = typeof stored.goalName === "string" && stored.goalName.trim() ? stored.goalName.trim().slice(0, 40) : current.goalName;
		const goalTargetCents = typeof stored.goalTargetCents === "number" && Number.isInteger(stored.goalTargetCents) && stored.goalTargetCents >= 0 ? stored.goalTargetCents : current.goalTargetCents;
		return {
			...current,
			transactions,
			goalName,
			goalTargetCents
		};
	}
}));
var fieldClass = "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none transition-[border-color,box-shadow] duration-150 focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";
function BudgetApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		Promise.resolve(useBudget.persist.rehydrate()).catch(() => void 0).then(() => {
			if (alive) setReady(true);
		});
		return () => {
			alive = false;
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-5xl px-4 py-8 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-medium tracking-tight",
			children: "Ledger"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Loading this month…"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetScreen, {});
}
function BudgetScreen() {
	const transactions = useBudget((state) => state.transactions);
	const goalName = useBudget((state) => state.goalName);
	const goalTargetCents = useBudget((state) => state.goalTargetCents);
	const addTransaction = useBudget((state) => state.addTransaction);
	const updateTransaction = useBudget((state) => state.updateTransaction);
	const deleteTransaction = useBudget((state) => state.deleteTransaction);
	const setGoalName = useBudget((state) => state.setGoalName);
	const setGoalTargetCents = useBudget((state) => state.setGoalTargetCents);
	const loadSample = useBudget((state) => state.loadSample);
	const current = monthKey(/* @__PURE__ */ new Date());
	const [month, setMonth] = (0, import_react.useState)(current);
	const [kindFilter, setKindFilter] = (0, import_react.useState)("all");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)(null);
	const [nameDraft, setNameDraft] = (0, import_react.useState)(goalName);
	const [targetDraft, setTargetDraft] = (0, import_react.useState)(centsToInput(goalTargetCents));
	const [targetFocused, setTargetFocused] = (0, import_react.useState)(false);
	const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	(0, import_react.useEffect)(() => {
		setNameDraft(goalName);
	}, [goalName]);
	(0, import_react.useEffect)(() => {
		if (!targetFocused) setTargetDraft(centsToInput(goalTargetCents));
	}, [goalTargetCents, targetFocused]);
	const monthRows = inMonth(transactions, month);
	const summary = summarize(monthRows);
	const goal = goalStanding(summary.remaining, goalTargetCents);
	const monthLabel = formatMonth(month);
	const third = thirdStat(summary.remaining, goalTargetCents, goal.state);
	const visible = monthRows.filter((transaction) => {
		if (kindFilter !== "all" && transaction.kind !== kindFilter) return false;
		if (categoryFilter && transaction.category !== categoryFilter) return false;
		return true;
	});
	function changeMonth(next) {
		setMonth(next);
		setCategoryFilter(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-6 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Monthly budget"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-medium tracking-tight",
					children: "Ledger"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-2 sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 rounded-lg border border-border bg-surface p-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Previous month",
								onClick: () => changeMonth(shiftMonth(month, -1)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "w-40 text-center text-sm font-medium tabular-nums",
								"aria-live": "polite",
								children: monthLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Next month",
								onClick: () => changeMonth(shiftMonth(month, 1)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							})
						]
					}), month !== current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 px-1 text-sm font-medium text-accent",
						onClick: () => changeMonth(current),
						children: "Back to this month"
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex min-w-0 flex-col rounded-2xl border border-border bg-surface p-5 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted",
							children: "Remaining"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-2 text-4xl font-semibold tracking-tight tabular-nums sm:text-5xl", summary.remaining < 0 ? "text-negative" : "text-fg"),
							children: formatMoney(summary.remaining)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-pretty text-muted",
							children: [
								"Income minus spending in ",
								monthLabel,
								"."
							]
						}),
						summary.incomeCategories.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-pretty text-muted",
							children: summary.incomeCategories.map((row) => `${row.category} ${formatMoney(row.cents)}`).join(" · ")
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 border-t border-border sm:grid sm:grid-cols-3 sm:gap-3 sm:pt-5 lg:mt-auto lg:pt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Income",
									value: formatMoney(summary.income),
									tone: "positive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Spent",
									value: formatMoney(summary.expenses),
									tone: "negative"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: third.label,
									value: third.value,
									tone: third.tone
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "min-w-0 rounded-2xl border border-border bg-surface p-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium text-muted",
								children: "Savings goal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold tabular-nums",
								children: goalTargetCents > 0 ? `${goal.pct}%` : "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-pretty text-fg",
							children: goalTargetCents > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold tabular-nums",
								children: formatMoney(goal.toward)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [
									" of ",
									formatMoney(goalTargetCents),
									" covered"
								]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Set a target for what you want left after spending."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-2 overflow-hidden rounded-full bg-track",
							role: "progressbar",
							"aria-valuemin": 0,
							"aria-valuemax": 100,
							"aria-valuenow": goal.pct,
							"aria-label": "Savings goal progress",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bar-fill h-full rounded-full bg-accent",
								style: { width: `${goal.pct}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-pretty text-muted",
							children: goalMessage(goal.state, summary.remaining, goalTargetCents)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-2",
								htmlFor: "goal-name",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "goal-name",
									className: fieldClass,
									value: nameDraft,
									maxLength: 40,
									autoComplete: "off",
									onChange: (event) => setNameDraft(event.target.value),
									onBlur: (event) => setGoalName(event.currentTarget.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-2",
								htmlFor: "goal-target",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Target"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted",
										"aria-hidden": true,
										children: "$"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "goal-target",
										className: cn(fieldClass, "pl-7 font-medium tabular-nums"),
										inputMode: "decimal",
										autoComplete: "off",
										value: targetDraft,
										onFocus: () => setTargetFocused(true),
										onChange: (event) => setTargetDraft(event.target.value),
										onBlur: (event) => {
											setTargetFocused(false);
											const next = event.currentTarget.value;
											const cents = parseDollarsToCents(next);
											if (cents === null) {
												if (next.trim() === "" || next.trim() === "0" || next.trim() === "0.00") {
													setGoalTargetCents(0);
													return;
												}
												setTargetDraft(centsToInput(goalTargetCents));
												return;
											}
											setGoalTargetCents(cents);
										}
									})]
								})]
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendingChart, {
				monthLabel,
				categories: summary.expenseCategories,
				activeCategory: categoryFilter,
				onSelectCategory: setCategoryFilter,
				reduceMotion
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid min-w-0 items-start gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 lg:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryForm, {
						month,
						onCreate: (input) => {
							addTransaction(input);
							const entryMonth = input.date.slice(0, 7);
							if (entryMonth !== month) changeMonth(entryMonth);
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 lg:col-span-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionList, {
						monthLabel,
						transactions: visible,
						kindFilter,
						categoryFilter,
						onKindFilter: setKindFilter,
						onClearCategory: () => setCategoryFilter(null),
						onUpdate: (id, input) => {
							updateTransaction(id, input);
							const entryMonth = input.date.slice(0, 7);
							if (entryMonth !== month) changeMonth(entryMonth);
						},
						onDelete: deleteTransaction,
						onLoadSample: () => loadSample(month),
						monthIsEmpty: monthRows.length === 0
					})
				})]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3 border-b border-border py-3 last:border-b-0 sm:block sm:border-b-0 sm:py-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("text-base font-semibold whitespace-nowrap tabular-nums", tone === "positive" && "text-positive", tone === "negative" && "text-negative"),
			children: value
		})]
	});
}
function thirdStat(remaining, targetCents, state) {
	if (targetCents <= 0 || state === "unset") return {
		label: "Left",
		value: formatMoney(remaining),
		tone: remaining < 0 ? "negative" : "neutral"
	};
	if (state === "covered") return {
		label: "Free",
		value: formatMoney(remaining - targetCents),
		tone: "positive"
	};
	if (state === "overspent") return {
		label: "Over",
		value: formatMoney(Math.abs(remaining)),
		tone: "negative"
	};
	return {
		label: "Short",
		value: formatMoney(targetCents - remaining),
		tone: "negative"
	};
}
function goalMessage(state, remaining, targetCents) {
	if (state === "unset") return "Progress appears once the target is above zero.";
	if (state === "overspent") return `Overspent by ${formatMoney(Math.abs(remaining))}. Nothing is left for this goal.`;
	if (state === "covered") {
		const free = remaining - targetCents;
		return free === 0 ? "Right on the target." : `Target covered, with ${formatMoney(free)} still free.`;
	}
	return `${formatMoney(targetCents - remaining)} short of keeping this target.`;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetApp, {});
}
//#endregion
export { Home as component };
