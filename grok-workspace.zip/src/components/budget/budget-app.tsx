import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useState } from "react";
import { EntryForm } from "@/components/budget/entry-form";
import { SpendingChart } from "@/components/budget/spending-chart";
import { TransactionList } from "@/components/budget/transaction-list";
import { Button } from "@/components/ui/button";
import {
  centsToInput,
  formatMoney,
  formatMonth,
  goalStanding,
  inMonth,
  monthKey,
  parseDollarsToCents,
  shiftMonth,
  summarize,
  type Kind,
} from "@/lib/budget/model";
import { useBudget } from "@/lib/budget/store";
import { cn } from "@/lib/utils";

const fieldClass =
  "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none transition-[border-color,box-shadow] duration-150 focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";

export function BudgetApp() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    void Promise.resolve(useBudget.persist.rehydrate())
      .catch(() => undefined)
      .then(() => {
        if (alive) setReady(true);
      });
    return () => {
      alive = false;
    };
  }, []);

  if (!ready) {
    return (
      <main className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6">
        <h1 className="font-display text-4xl font-medium tracking-tight">Ledger</h1>
        <p className="mt-2 text-sm text-muted">Loading this month…</p>
      </main>
    );
  }

  return <BudgetScreen />;
}

function BudgetScreen() {
  const transactions = useBudget((state) => state.transactions);
  const goalName = useBudget((state) => state.goalName);
  const goalTargetCents = useBudget((state) => state.goalTargetCents);
  const addTransaction = useBudget((state) => state.addTransaction);
  const updateTransaction = useBudget((state) => state.updateTransaction);
  const deleteTransaction = useBudget((state) => state.deleteTransaction);
  const setGoalName = useBudget((state) => state.setGoalName);
  const setGoalTargetCents = useBudget((state) => state.setGoalTargetCents);
  const loadSample = useBudget((state) => state.loadSample);

  const current = monthKey(new Date());
  const [month, setMonth] = useState(current);
  const [kindFilter, setKindFilter] = useState<"all" | Kind>("all");
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [nameDraft, setNameDraft] = useState(goalName);
  const [targetDraft, setTargetDraft] = useState(centsToInput(goalTargetCents));
  const [targetFocused, setTargetFocused] = useState(false);
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  useEffect(() => {
    setNameDraft(goalName);
  }, [goalName]);

  useEffect(() => {
    if (!targetFocused) setTargetDraft(centsToInput(goalTargetCents));
  }, [goalTargetCents, targetFocused]);

  const monthRows = inMonth(transactions, month);
  const summary = summarize(monthRows);
  const goal = goalStanding(summary.remaining, goalTargetCents);
  const monthLabel = formatMonth(month);
  const third = thirdStat(summary.remaining, goalTargetCents, goal.state);
  const visible = monthRows.filter((transaction) => {
    if (kindFilter !== "all" && transaction.kind !== kindFilter) return false;
    if (categoryFilter && transaction.category !== categoryFilter) return false;
    return true;
  });

  function changeMonth(next: string) {
    setMonth(next);
    setCategoryFilter(null);
  }

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-6 sm:px-6 sm:py-10">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-medium text-muted">Monthly budget</p>
          <h1 className="font-display text-4xl font-medium tracking-tight">Ledger</h1>
        </div>
        <div className="flex flex-col items-start gap-2 sm:items-end">
          <div className="flex items-center gap-1 rounded-lg border border-border bg-surface p-1">
            <Button variant="ghost" size="icon" aria-label="Previous month" onClick={() => changeMonth(shiftMonth(month, -1))}>
              <ChevronLeft className="size-4" />
            </Button>
            <p className="w-40 text-center text-sm font-medium tabular-nums" aria-live="polite">
              {monthLabel}
            </p>
            <Button variant="ghost" size="icon" aria-label="Next month" onClick={() => changeMonth(shiftMonth(month, 1))}>
              <ChevronRight className="size-4" />
            </Button>
          </div>
          {month !== current ? (
            <button type="button" className="h-11 px-1 text-sm font-medium text-accent" onClick={() => changeMonth(current)}>
              Back to this month
            </button>
          ) : null}
        </div>
      </header>

      <section className="grid gap-4 lg:grid-cols-5">
        <article className="flex min-w-0 flex-col rounded-2xl border border-border bg-surface p-5 lg:col-span-3">
          <h2 className="text-sm font-medium text-muted">Remaining</h2>
          <p
            className={cn(
              "mt-2 text-4xl font-semibold tracking-tight tabular-nums sm:text-5xl",
              summary.remaining < 0 ? "text-negative" : "text-fg",
            )}
          >
            {formatMoney(summary.remaining)}
          </p>
          <p className="mt-2 text-sm text-pretty text-muted">Income minus spending in {monthLabel}.</p>
          {summary.incomeCategories.length > 0 ? (
            <p className="mt-3 text-sm text-pretty text-muted">
              {summary.incomeCategories.map((row) => `${row.category} ${formatMoney(row.cents)}`).join(" · ")}
            </p>
          ) : null}
          <dl className="mt-6 border-t border-border sm:grid sm:grid-cols-3 sm:gap-3 sm:pt-5 lg:mt-auto lg:pt-6">
            <Stat label="Income" value={formatMoney(summary.income)} tone="positive" />
            <Stat label="Spent" value={formatMoney(summary.expenses)} tone="negative" />
            <Stat label={third.label} value={third.value} tone={third.tone} />
          </dl>
        </article>

        <article className="min-w-0 rounded-2xl border border-border bg-surface p-5 lg:col-span-2">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium text-muted">Savings goal</h2>
            <p className="text-2xl font-semibold tabular-nums">{goalTargetCents > 0 ? `${goal.pct}%` : "—"}</p>
          </div>
          <p className="mt-3 text-sm text-pretty text-fg">
            {goalTargetCents > 0 ? (
              <>
                <span className="font-semibold tabular-nums">{formatMoney(goal.toward)}</span>
                <span className="text-muted"> of {formatMoney(goalTargetCents)} covered</span>
              </>
            ) : (
              <span className="text-muted">Set a target for what you want left after spending.</span>
            )}
          </p>
          <div
            className="mt-4 h-2 overflow-hidden rounded-full bg-track"
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={goal.pct}
            aria-label="Savings goal progress"
          >
            <div className="bar-fill h-full rounded-full bg-accent" style={{ width: `${goal.pct}%` }} />
          </div>
          <p className="mt-3 text-sm text-pretty text-muted">{goalMessage(goal.state, summary.remaining, goalTargetCents)}</p>
          <div className="mt-5 grid gap-4">
            <label className="flex flex-col gap-2" htmlFor="goal-name">
              <span className="text-sm font-medium">Name</span>
              <input
                id="goal-name"
                className={fieldClass}
                value={nameDraft}
                maxLength={40}
                autoComplete="off"
                onChange={(event) => setNameDraft(event.target.value)}
                onBlur={(event) => setGoalName(event.currentTarget.value)}
              />
            </label>
            <label className="flex flex-col gap-2" htmlFor="goal-target">
              <span className="text-sm font-medium">Target</span>
              <span className="relative">
                <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" aria-hidden>
                  $
                </span>
                <input
                  id="goal-target"
                  className={cn(fieldClass, "pl-7 font-medium tabular-nums")}
                  inputMode="decimal"
                  autoComplete="off"
                  value={targetDraft}
                  onFocus={() => setTargetFocused(true)}
                  onChange={(event) => setTargetDraft(event.target.value)}
                  onBlur={(event) => {
                    setTargetFocused(false);
                    const next = event.currentTarget.value;
                    const cents = parseDollarsToCents(next);
                    if (cents === null) {
                      if (next.trim() === "" || next.trim() === "0" || next.trim() === "0.00") {
                        setGoalTargetCents(0);
                        return;
                      }
                      setTargetDraft(centsToInput(goalTargetCents));
                      return;
                    }
                    setGoalTargetCents(cents);
                  }}
                />
              </span>
            </label>
          </div>
        </article>
      </section>

      <SpendingChart
        monthLabel={monthLabel}
        categories={summary.expenseCategories}
        activeCategory={categoryFilter}
        onSelectCategory={setCategoryFilter}
        reduceMotion={reduceMotion}
      />

      <section className="grid min-w-0 items-start gap-4 lg:grid-cols-5">
        <div className="min-w-0 lg:col-span-2">
          <EntryForm
            month={month}
            onCreate={(input) => {
              addTransaction(input);
              const entryMonth = input.date.slice(0, 7);
              if (entryMonth !== month) changeMonth(entryMonth);
            }}
          />
        </div>
        <div className="min-w-0 lg:col-span-3">
          <TransactionList
            monthLabel={monthLabel}
            transactions={visible}
            kindFilter={kindFilter}
            categoryFilter={categoryFilter}
            onKindFilter={setKindFilter}
            onClearCategory={() => setCategoryFilter(null)}
            onUpdate={(id, input) => {
              updateTransaction(id, input);
              const entryMonth = input.date.slice(0, 7);
              if (entryMonth !== month) changeMonth(entryMonth);
            }}
            onDelete={deleteTransaction}
            onLoadSample={() => loadSample(month)}
            monthIsEmpty={monthRows.length === 0}
          />
        </div>
      </section>
    </main>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "positive" | "negative" | "neutral" }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-border py-3 last:border-b-0 sm:block sm:border-b-0 sm:py-0">
      <dt className="text-sm text-muted">{label}</dt>
      <dd
        className={cn(
          "text-base font-semibold whitespace-nowrap tabular-nums",
          tone === "positive" && "text-positive",
          tone === "negative" && "text-negative",
        )}
      >
        {value}
      </dd>
    </div>
  );
}

function thirdStat(remaining: number, targetCents: number, state: ReturnType<typeof goalStanding>["state"]) {
  if (targetCents <= 0 || state === "unset") {
    return {
      label: "Left",
      value: formatMoney(remaining),
      tone: remaining < 0 ? ("negative" as const) : ("neutral" as const),
    };
  }
  if (state === "covered") {
    return { label: "Free", value: formatMoney(remaining - targetCents), tone: "positive" as const };
  }
  if (state === "overspent") {
    return { label: "Over", value: formatMoney(Math.abs(remaining)), tone: "negative" as const };
  }
  return { label: "Short", value: formatMoney(targetCents - remaining), tone: "negative" as const };
}

function goalMessage(state: ReturnType<typeof goalStanding>["state"], remaining: number, targetCents: number): string {
  if (state === "unset") return "Progress appears once the target is above zero.";
  if (state === "overspent") return `Overspent by ${formatMoney(Math.abs(remaining))}. Nothing is left for this goal.`;
  if (state === "covered") {
    const free = remaining - targetCents;
    return free === 0 ? "Right on the target." : `Target covered, with ${formatMoney(free)} still free.`;
  }
  return `${formatMoney(targetCents - remaining)} short of keeping this target.`;
}
