import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { useEffect, useId, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import {
  categoriesFor,
  defaultDateForMonth,
  emptyDraft,
  formatMoney,
  formatMonth,
  parseDraft,
  type EntryDraft,
  type Kind,
  type TransactionInput,
} from "@/lib/budget/model";
import { cn } from "@/lib/utils";

const fieldClass =
  "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";

type EntryFieldsProps = {
  draft: EntryDraft;
  onChange: (draft: EntryDraft) => void;
  error?: string;
  idPrefix: string;
};

export function EntryFields({ draft, onChange, error, idPrefix }: EntryFieldsProps) {
  const errorId = useId();
  const presets = categoriesFor(draft.kind);

  function patch(partial: Partial<EntryDraft>) {
    onChange({ ...draft, ...partial });
  }

  function setKind(kind: Kind) {
    if (kind === draft.kind) return;
    const other = categoriesFor(draft.kind);
    const nextCategory = other.includes(draft.category) ? (kind === "income" ? "Salary" : "Groceries") : draft.category;
    onChange({ ...draft, kind, category: nextCategory });
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-1 rounded-lg bg-surface-muted p-1" role="group" aria-label="Entry type">
        {(["expense", "income"] as const).map((kind) => {
          const selected = draft.kind === kind;
          return (
            <button
              key={kind}
              type="button"
              aria-pressed={selected}
              onClick={() => setKind(kind)}
              className={cn(
                "h-11 rounded-md text-sm font-medium capitalize transition-[background-color,color,box-shadow] duration-150",
                selected ? "bg-surface text-fg shadow-panel" : "text-muted hover:text-fg",
              )}
            >
              {kind}
            </button>
          );
        })}
      </div>

      <label className="flex flex-col gap-2" htmlFor={`${idPrefix}-amount`}>
        <span className="text-sm font-medium">Amount</span>
        <span className="relative">
          <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" aria-hidden>
            $
          </span>
          <input
            id={`${idPrefix}-amount`}
            className={cn(fieldClass, "pl-7 font-medium tabular-nums")}
            inputMode="decimal"
            autoComplete="off"
            placeholder="0.00"
            value={draft.amount}
            aria-invalid={error ? true : undefined}
            aria-describedby={error ? errorId : undefined}
            onChange={(event) => patch({ amount: event.target.value })}
          />
        </span>
      </label>

      <div className="flex flex-col gap-2">
        <span className="text-sm font-medium" id={`${idPrefix}-category-label`}>
          Category
        </span>
        <div className="flex flex-wrap gap-2" role="group" aria-labelledby={`${idPrefix}-category-label`}>
          {presets.map((category) => {
            const selected = draft.category === category;
            return (
              <button
                key={category}
                type="button"
                aria-pressed={selected}
                onClick={() => patch({ category })}
                className={cn(
                  "h-11 rounded-full border px-3 text-sm font-medium transition-[background-color,color,border-color] duration-150",
                  selected
                    ? "border-accent bg-accent text-accent-fg"
                    : "border-border bg-surface text-fg hover:bg-surface-muted",
                )}
              >
                {category}
              </button>
            );
          })}
        </div>
        <input
          id={`${idPrefix}-category`}
          className={fieldClass}
          aria-labelledby={`${idPrefix}-category-label`}
          autoComplete="off"
          maxLength={40}
          placeholder="Or type your own"
          value={draft.category}
          onChange={(event) => patch({ category: event.target.value })}
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="flex flex-col gap-2" htmlFor={`${idPrefix}-date`}>
          <span className="text-sm font-medium">Date</span>
          <input
            id={`${idPrefix}-date`}
            className={cn(fieldClass, "tabular-nums")}
            type="date"
            value={draft.date}
            onChange={(event) => patch({ date: event.target.value })}
          />
        </label>
        <label className="flex flex-col gap-2" htmlFor={`${idPrefix}-note`}>
          <span className="text-sm font-medium">Note</span>
          <input
            id={`${idPrefix}-note`}
            className={fieldClass}
            autoComplete="off"
            maxLength={80}
            placeholder="Optional"
            value={draft.note}
            onChange={(event) => patch({ note: event.target.value })}
          />
        </label>
      </div>

      {error ? (
        <p id={errorId} role="alert" className="text-sm text-negative">
          {error}
        </p>
      ) : null}
    </div>
  );
}

type EntryFormProps = {
  month: string;
  onCreate: (input: TransactionInput) => void;
};

export function EntryForm({ month, onCreate }: EntryFormProps) {
  const [draft, setDraft] = useState<EntryDraft>(() => emptyDraft(month));
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    setDraft((current) => {
      if (current.date.startsWith(month)) return current;
      return { ...current, date: defaultDateForMonth(month) };
    });
  }, [month]);

  function submit(event: FormEvent) {
    event.preventDefault();
    const parsed = parseDraft(draft);
    if (!parsed.ok) {
      setError(parsed.error);
      setNotice("");
      return;
    }
    onCreate(parsed.value);
    setDraft({ ...draft, amount: "", note: "" });
    setError("");
    setNotice(`Added ${formatMoney(parsed.value.amountCents)} to ${formatMonth(parsed.value.date.slice(0, 7))}.`);
  }

  return (
    <section className="rounded-2xl border border-border bg-surface p-5">
      <h2 className="font-display text-2xl font-medium tracking-tight">New entry</h2>
      <p className="mt-1 text-sm text-pretty text-muted">Income or an expense. The balance updates immediately.</p>
      <form className="mt-5 flex flex-col gap-4" onSubmit={submit}>
        <EntryFields
          draft={draft}
          idPrefix="new"
          error={error}
          onChange={(next) => {
            setDraft(next);
            if (notice) setNotice("");
          }}
        />
        <Button type="submit">{draft.kind === "income" ? "Add income" : "Add expense"}</Button>
        <p role="status" className="min-h-5 text-sm text-positive">
          {notice}
        </p>
      </form>
    </section>
  );
}

type EditDialogProps = {
  draft: EntryDraft | null;
  onChange: (draft: EntryDraft) => void;
  onOpenChange: (open: boolean) => void;
  onSave: (input: TransactionInput) => void;
};

export function EditDialog({ draft, onChange, onOpenChange, onSave }: EditDialogProps) {
  const [error, setError] = useState("");
  const open = draft !== null;

  function save(event: FormEvent) {
    event.preventDefault();
    if (!draft) return;
    const parsed = parseDraft(draft);
    if (!parsed.ok) {
      setError(parsed.error);
      return;
    }
    onSave(parsed.value);
  }

  return (
    <Dialog.Root
      open={open}
      onOpenChange={(next) => {
        if (!next) {
          setError("");
          onOpenChange(false);
        }
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay className="overlay-fade fixed inset-0 z-40 bg-fg/40" />
        <Dialog.Content
          className="dialog-pop fixed top-1/2 right-4 left-4 z-50 mx-auto w-full max-w-md overflow-y-auto rounded-2xl border border-border bg-surface p-5 shadow-panel"
          aria-describedby="edit-entry-description"
          onOpenAutoFocus={(event) => {
            event.preventDefault();
            document.getElementById("edit-amount")?.focus();
          }}
        >
          {draft ? (
            <form onSubmit={save}>
              <Dialog.Title className="pr-12 font-display text-2xl font-medium tracking-tight">Edit entry</Dialog.Title>
              <Dialog.Description id="edit-entry-description" className="mt-1 text-sm text-muted">
                Changes apply to this month’s balance right away.
              </Dialog.Description>
              <div className="mt-5">
                <EntryFields
                  draft={draft}
                  idPrefix="edit"
                  error={error}
                  onChange={(next) => {
                    setError("");
                    onChange(next);
                  }}
                />
              </div>
              <div className="mt-5 flex justify-end gap-2">
                <Dialog.Close asChild>
                  <Button variant="secondary">Cancel</Button>
                </Dialog.Close>
                <Button type="submit">Save</Button>
              </div>
            </form>
          ) : null}
          <Dialog.Close asChild>
            <Button variant="ghost" size="icon" className="absolute top-3 right-3" aria-label="Close">
              <X className="size-4" />
            </Button>
          </Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
