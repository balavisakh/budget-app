import { Pencil, Trash2, X } from "lucide-react";
import { useState } from "react";
import { EditDialog } from "@/components/budget/entry-form";
import { Button } from "@/components/ui/button";
import {
  draftFromTransaction,
  formatDay,
  formatMoney,
  type EntryDraft,
  type Kind,
  type Transaction,
  type TransactionInput,
} from "@/lib/budget/model";
import { cn } from "@/lib/utils";

type KindFilter = "all" | Kind;

type TransactionListProps = {
  monthLabel: string;
  transactions: Transaction[];
  kindFilter: KindFilter;
  categoryFilter: string | null;
  onKindFilter: (filter: KindFilter) => void;
  onClearCategory: () => void;
  onUpdate: (id: string, input: TransactionInput) => void;
  onDelete: (id: string) => void;
  onLoadSample: () => void;
  monthIsEmpty: boolean;
};

const filters: Array<{ id: KindFilter; label: string }> = [
  { id: "all", label: "All" },
  { id: "income", label: "Income" },
  { id: "expense", label: "Expenses" },
];

export function TransactionList({
  monthLabel,
  transactions,
  kindFilter,
  categoryFilter,
  onKindFilter,
  onClearCategory,
  onUpdate,
  onDelete,
  onLoadSample,
  monthIsEmpty,
}: TransactionListProps) {
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [editDraft, setEditDraft] = useState<EntryDraft | null>(null);

  function openEdit(transaction: Transaction) {
    setConfirmId(null);
    setEditing(transaction);
    setEditDraft(draftFromTransaction(transaction));
  }

  return (
    <section className="rounded-2xl border border-border bg-surface p-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-medium tracking-tight">Entries</h2>
          <p className="mt-1 text-sm text-muted">
            {transactions.length} in view · {monthLabel}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {categoryFilter ? (
            <button
              type="button"
              onClick={onClearCategory}
              className="inline-flex h-11 items-center gap-2 rounded-full border border-border bg-surface-muted px-3 text-sm font-medium"
            >
              {categoryFilter}
              <span className="sr-only">Clear category filter</span>
              <X className="size-4 text-muted" aria-hidden />
            </button>
          ) : null}
          <div className="grid shrink-0 grid-cols-3 gap-1 rounded-lg bg-surface-muted p-1" role="group" aria-label="Filter entries">
            {filters.map((filter) => {
              const selected = kindFilter === filter.id;
              return (
                <button
                  key={filter.id}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => onKindFilter(filter.id)}
                  className={cn(
                    "h-11 rounded-md px-3 text-sm font-medium transition-[background-color,color,box-shadow] duration-150",
                    selected ? "bg-surface text-fg shadow-panel" : "text-muted hover:text-fg",
                  )}
                >
                  {filter.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {monthIsEmpty ? (
        <div className="mt-6 rounded-md border border-dashed border-border px-4 py-8 text-center">
          <p className="text-sm text-pretty text-muted">Nothing recorded in {monthLabel}.</p>
          <Button className="mt-4" variant="secondary" onClick={onLoadSample}>
            Load sample entries
          </Button>
        </div>
      ) : transactions.length === 0 ? (
        <p className="mt-6 text-sm text-muted">No entries match this filter.</p>
      ) : (
        <ul className="mt-4">
          {transactions.map((transaction) => {
            const confirming = confirmId === transaction.id;
            const signed = transaction.kind === "income" ? transaction.amountCents : -transaction.amountCents;
            const detail = transaction.note
              ? `${formatDay(transaction.date)} · ${transaction.note}`
              : `${formatDay(transaction.date)} · ${transaction.kind === "income" ? "Income" : "Expense"}`;
            return (
              <li key={transaction.id} className="border-t border-border first:border-t-0">
                <div className="flex items-center gap-2 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{transaction.category}</p>
                    <p className="truncate text-sm text-muted">{detail}</p>
                  </div>
                  <p
                    className={cn(
                      "w-28 shrink-0 text-right text-sm font-semibold whitespace-nowrap tabular-nums sm:text-base",
                      transaction.kind === "income" ? "text-positive" : "text-negative",
                    )}
                  >
                    {formatMoney(signed)}
                  </p>
                  <div className="flex shrink-0">
                    <Button variant="ghost" size="icon" aria-label={`Edit ${transaction.category}`} onClick={() => openEdit(transaction)}>
                      <Pencil className="size-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label={`Delete ${transaction.category}`}
                      aria-expanded={confirming}
                      onClick={() => setConfirmId(confirming ? null : transaction.id)}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
                {confirming ? (
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3">
                    <p className="text-sm text-muted">Delete this {formatMoney(transaction.amountCents)} entry?</p>
                    <div className="flex gap-2">
                      <Button variant="secondary" onClick={() => setConfirmId(null)}>
                        Keep
                      </Button>
                      <Button
                        variant="danger"
                        onClick={() => {
                          onDelete(transaction.id);
                          setConfirmId(null);
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}

      <p className="mt-4 text-xs text-muted">Entries stay on this device.</p>

      <EditDialog
        draft={editDraft}
        onChange={setEditDraft}
        onOpenChange={(open) => {
          if (!open) {
            setEditing(null);
            setEditDraft(null);
          }
        }}
        onSave={(input) => {
          if (!editing) return;
          onUpdate(editing.id, input);
          setEditing(null);
          setEditDraft(null);
        }}
      />
    </section>
  );
}
