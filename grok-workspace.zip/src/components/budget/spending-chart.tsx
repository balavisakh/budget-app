import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatMoney, type CategorySpend } from "@/lib/budget/model";
import { cn } from "@/lib/utils";

type SpendingChartProps = {
  monthLabel: string;
  categories: CategorySpend[];
  activeCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  reduceMotion: boolean;
};

function Tip({ active, payload }: { active?: boolean; payload?: Array<{ payload?: CategorySpend }> }) {
  const row = payload?.[0]?.payload;
  if (!active || !row) return null;
  return (
    <div className="rounded-md border border-border bg-surface px-3 py-2 text-sm shadow-panel">
      <p className="font-medium">{row.category}</p>
      <p className="tabular-nums text-muted">
        {formatMoney(row.cents)} · {row.pct}%
      </p>
    </div>
  );
}

export function SpendingChart({
  monthLabel,
  categories,
  activeCategory,
  onSelectCategory,
  reduceMotion,
}: SpendingChartProps) {
  return (
    <section className="min-w-0 rounded-2xl border border-border bg-surface p-5">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-2xl font-medium tracking-tight">Spending</h2>
        <p className="text-sm text-muted">{monthLabel}</p>
      </div>
      {categories.length === 0 ? (
        <p className="mt-6 text-sm text-pretty text-muted">No expenses in {monthLabel} yet. Add one to see the breakdown.</p>
      ) : (
        <div className="mt-5 grid items-center gap-6 lg:grid-cols-2">
          <div className="h-56 min-w-0" aria-hidden="true">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categories} layout="vertical" margin={{ top: 4, right: 8, left: 0, bottom: 4 }}>
                <XAxis type="number" hide domain={[0, "dataMax"]} />
                <YAxis
                  type="category"
                  dataKey="category"
                  width={92}
                  interval={0}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickFormatter={(value: string) => (value.length > 14 ? `${value.slice(0, 13)}…` : value)}
                />
                <Tooltip cursor={{ fill: "var(--color-surface-muted)" }} content={<Tip />} />
                <Bar dataKey="cents" barSize={14} radius={[0, 6, 6, 0]} isAnimationActive={!reduceMotion}>
                  {categories.map((row) => (
                    <Cell
                      key={row.category}
                      fill="var(--color-accent)"
                      fillOpacity={!activeCategory || activeCategory === row.category ? 1 : 0.35}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div>
            <div className="flex items-baseline justify-between gap-3 text-xs font-medium text-muted">
              <span>Category</span>
              <span>Amount</span>
            </div>
            <ul className="mt-1">
              {categories.map((row) => {
                const selected = activeCategory === row.category;
                return (
                  <li key={row.category} className="border-t border-border first:border-t-0">
                    <button
                      type="button"
                      aria-pressed={selected}
                      onClick={() => onSelectCategory(selected ? null : row.category)}
                      className={cn(
                        "flex h-11 w-full items-center justify-between gap-3 rounded-md px-2 text-left transition-colors duration-150",
                        selected ? "bg-surface-muted" : "hover:bg-surface-muted",
                      )}
                    >
                      <span className="truncate text-sm font-medium">{row.category}</span>
                      <span className="shrink-0 text-sm tabular-nums">
                        <span className="font-semibold">{formatMoney(row.cents)}</span>
                        <span className="ml-3 inline-block w-10 text-right text-muted">
                          <span className="sr-only">, </span>
                          {row.pct}%
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
            <p className="mt-3 text-xs text-muted">Select a category to filter the list below.</p>
          </div>
        </div>
      )}
    </section>
  );
}
