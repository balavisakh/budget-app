export type Kind = "income" | "expense";

export type Transaction = {
  id: string;
  kind: Kind;
  amountCents: number;
  category: string;
  note: string;
  date: string;
};

export type TransactionInput = Omit<Transaction, "id">;

export type EntryDraft = {
  kind: Kind;
  amount: string;
  category: string;
  date: string;
  note: string;
};

export const EXPENSE_CATEGORIES = [
  "Housing",
  "Groceries",
  "Transport",
  "Dining",
  "Utilities",
  "Health",
  "Personal",
] as const;

export const INCOME_CATEGORIES = ["Salary", "Freelance", "Other"] as const;

const MAX_CENTS = 100_000_000;

const money = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

export function formatMoney(cents: number): string {
  return money.format(cents / 100);
}

export function centsToInput(cents: number): string {
  return (cents / 100).toFixed(2);
}

export function monthKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export function shiftMonth(month: string, delta: number): string {
  const [year, monthIndex] = month.split("-").map(Number);
  return monthKey(new Date(year, monthIndex - 1 + delta, 1));
}

export function formatMonth(month: string): string {
  const [year, monthIndex] = month.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(
    new Date(year, monthIndex - 1, 1),
  );
}

export function formatDay(iso: string): string {
  const [year, monthIndex, day] = iso.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(
    new Date(year, monthIndex - 1, day),
  );
}

export function defaultDateForMonth(month: string, today = new Date()): string {
  if (month === monthKey(today)) {
    return `${month}-${String(today.getDate()).padStart(2, "0")}`;
  }
  return `${month}-01`;
}

function dateInMonth(month: string, day: number): string {
  const [year, monthIndex] = month.split("-").map(Number);
  const last = new Date(year, monthIndex, 0).getDate();
  const clamped = Math.min(Math.max(1, day), last);
  return `${month}-${String(clamped).padStart(2, "0")}`;
}

export function buildSample(month: string): Transaction[] {
  const rows: Array<Omit<Transaction, "id" | "date"> & { day: number }> = [
    { day: 1, kind: "income", amountCents: 520000, category: "Salary", note: "Payroll" },
    { day: 12, kind: "income", amountCents: 84000, category: "Freelance", note: "Studio invoice" },
    { day: 1, kind: "expense", amountCents: 165000, category: "Housing", note: "Rent" },
    { day: 4, kind: "expense", amountCents: 8640, category: "Groceries", note: "Market run" },
    { day: 5, kind: "expense", amountCents: 9200, category: "Transport", note: "Monthly pass" },
    { day: 8, kind: "expense", amountCents: 4820, category: "Dining", note: "Dinner out" },
    { day: 11, kind: "expense", amountCents: 12415, category: "Utilities", note: "Electric and water" },
    { day: 14, kind: "expense", amountCents: 6380, category: "Groceries", note: "Midweek shop" },
    { day: 18, kind: "expense", amountCents: 2850, category: "Health", note: "Pharmacy" },
    { day: 21, kind: "expense", amountCents: 3410, category: "Dining", note: "Lunch" },
    { day: 23, kind: "expense", amountCents: 7125, category: "Groceries", note: "Weekend shop" },
    { day: 26, kind: "expense", amountCents: 1599, category: "Personal", note: "Subscriptions" },
  ];

  return rows.map((row, index) => ({
    id: `${month}-sample-${index + 1}`,
    kind: row.kind,
    amountCents: row.amountCents,
    category: row.category,
    note: row.note,
    date: dateInMonth(month, row.day),
  }));
}

export function isTransaction(value: unknown): value is Transaction {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<Transaction>;
  return (
    typeof row.id === "string" &&
    (row.kind === "income" || row.kind === "expense") &&
    typeof row.amountCents === "number" &&
    Number.isInteger(row.amountCents) &&
    row.amountCents > 0 &&
    typeof row.category === "string" &&
    row.category.trim().length > 0 &&
    typeof row.note === "string" &&
    typeof row.date === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(row.date)
  );
}

export function categoriesFor(kind: Kind): readonly string[] {
  return kind === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
}

export function emptyDraft(month: string, today = new Date()): EntryDraft {
  return {
    kind: "expense",
    amount: "",
    category: "Groceries",
    date: defaultDateForMonth(month, today),
    note: "",
  };
}

export function draftFromTransaction(transaction: Transaction): EntryDraft {
  return {
    kind: transaction.kind,
    amount: centsToInput(transaction.amountCents),
    category: transaction.category,
    date: transaction.date,
    note: transaction.note,
  };
}

function isRealDate(iso: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) return false;
  const year = Number(match[1]);
  const monthIndex = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(year, monthIndex - 1, day);
  return date.getFullYear() === year && date.getMonth() === monthIndex - 1 && date.getDate() === day;
}

export function parseDollarsToCents(input: string): number | null {
  const cleaned = input.trim().replace(/[$,]/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
  const [whole, fraction = ""] = cleaned.split(".");
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
  if (!Number.isInteger(cents) || cents <= 0 || cents > MAX_CENTS) return null;
  return cents;
}

export function parseDraft(draft: EntryDraft): { ok: true; value: TransactionInput } | { ok: false; error: string } {
  const amountCents = parseDollarsToCents(draft.amount);
  if (amountCents === null) {
    return { ok: false, error: "Enter an amount from $0.01 to $1,000,000." };
  }
  const category = draft.category.trim().replace(/\s+/g, " ");
  if (!category || category.length > 40) {
    return { ok: false, error: "Add a category, up to 40 characters." };
  }
  if (!isRealDate(draft.date)) {
    return { ok: false, error: "Choose a valid date." };
  }
  const note = draft.note.trim().replace(/\s+/g, " ").slice(0, 80);
  return {
    ok: true,
    value: {
      kind: draft.kind,
      amountCents,
      category,
      date: draft.date,
      note,
    },
  };
}

export type CategorySpend = {
  category: string;
  cents: number;
  pct: number;
};

export type MonthSummary = {
  income: number;
  expenses: number;
  remaining: number;
  incomeCategories: CategorySpend[];
  expenseCategories: CategorySpend[];
};

function withPercents(entries: Array<{ category: string; cents: number }>, total: number): CategorySpend[] {
  if (total <= 0 || entries.length === 0) return [];
  const ranked = entries
    .map((entry) => {
      const exact = (entry.cents / total) * 100;
      return { ...entry, pct: Math.floor(exact), frac: exact - Math.floor(exact) };
    })
    .sort((a, b) => b.frac - a.frac || b.cents - a.cents);
  let leftover = 100 - ranked.reduce((sum, entry) => sum + entry.pct, 0);
  for (const entry of ranked) {
    if (leftover <= 0) break;
    entry.pct += 1;
    leftover -= 1;
  }
  return ranked
    .map(({ category, cents, pct }) => ({ category, cents, pct }))
    .sort((a, b) => b.cents - a.cents || a.category.localeCompare(b.category));
}

export function summarize(transactions: Transaction[]): MonthSummary {
  let income = 0;
  let expenses = 0;
  const incomeMap = new Map<string, number>();
  const expenseMap = new Map<string, number>();
  for (const transaction of transactions) {
    if (transaction.kind === "income") {
      income += transaction.amountCents;
      incomeMap.set(transaction.category, (incomeMap.get(transaction.category) ?? 0) + transaction.amountCents);
    } else {
      expenses += transaction.amountCents;
      expenseMap.set(transaction.category, (expenseMap.get(transaction.category) ?? 0) + transaction.amountCents);
    }
  }
  return {
    income,
    expenses,
    remaining: income - expenses,
    incomeCategories: withPercents(
      [...incomeMap.entries()].map(([category, cents]) => ({ category, cents })),
      income,
    ),
    expenseCategories: withPercents(
      [...expenseMap.entries()].map(([category, cents]) => ({ category, cents })),
      expenses,
    ),
  };
}

export function inMonth(transactions: Transaction[], month: string): Transaction[] {
  return transactions
    .filter((transaction) => transaction.date.startsWith(`${month}-`))
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
}

export function goalStanding(remaining: number, targetCents: number) {
  if (targetCents <= 0) {
    return { pct: 0, toward: 0, gap: remaining, state: "unset" as const };
  }
  if (remaining < 0) {
    return { pct: 0, toward: 0, gap: remaining - targetCents, state: "overspent" as const };
  }
  const toward = Math.min(remaining, targetCents);
  const pct = Math.round((toward / targetCents) * 100);
  if (remaining >= targetCents) {
    return { pct: 100, toward: targetCents, gap: remaining - targetCents, state: "covered" as const };
  }
  return { pct, toward, gap: remaining - targetCents, state: "short" as const };
}
