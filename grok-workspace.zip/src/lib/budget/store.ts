import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  buildSample,
  isTransaction,
  monthKey,
  type Transaction,
  type TransactionInput,
} from "@/lib/budget/model";

const memoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

type BudgetState = {
  transactions: Transaction[];
  goalName: string;
  goalTargetCents: number;
  addTransaction: (input: TransactionInput) => void;
  updateTransaction: (id: string, input: TransactionInput) => void;
  deleteTransaction: (id: string) => void;
  setGoalName: (name: string) => void;
  setGoalTargetCents: (cents: number) => void;
  loadSample: (month: string) => void;
};

function initialTransactions(): Transaction[] {
  return buildSample(monthKey(new Date()));
}

export const useBudget = create<BudgetState>()(
  persist(
    (set) => ({
      transactions: initialTransactions(),
      goalName: "Emergency fund",
      goalTargetCents: 480_000,
      addTransaction: (input) =>
        set((state) => ({
          transactions: [{ ...input, id: crypto.randomUUID() }, ...state.transactions],
        })),
      updateTransaction: (id, input) =>
        set((state) => ({
          transactions: state.transactions.map((transaction) =>
            transaction.id === id ? { ...input, id } : transaction,
          ),
        })),
      deleteTransaction: (id) =>
        set((state) => ({
          transactions: state.transactions.filter((transaction) => transaction.id !== id),
        })),
      setGoalName: (name) => set({ goalName: name.trim().slice(0, 40) || "Savings" }),
      setGoalTargetCents: (cents) => set({ goalTargetCents: cents }),
      loadSample: (month) =>
        set((state) => {
          if (state.transactions.some((transaction) => transaction.date.startsWith(`${month}-`))) {
            return state;
          }
          return { transactions: [...buildSample(month), ...state.transactions] };
        }),
    }),
    {
      name: "ledger-budget-v1",
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memoryStorage : localStorage)),
      merge: (persisted, current) => {
        const stored = (persisted ?? {}) as Partial<BudgetState>;
        const transactions = Array.isArray(stored.transactions) ? stored.transactions.filter(isTransaction) : current.transactions;
        const goalName = typeof stored.goalName === "string" && stored.goalName.trim() ? stored.goalName.trim().slice(0, 40) : current.goalName;
        const goalTargetCents =
          typeof stored.goalTargetCents === "number" && Number.isInteger(stored.goalTargetCents) && stored.goalTargetCents >= 0
            ? stored.goalTargetCents
            : current.goalTargetCents;
        return { ...current, transactions, goalName, goalTargetCents };
      },
    },
  ),
);
